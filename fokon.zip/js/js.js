$(document).ready(function () {

    
    $(".offer__pic__plus__left").click(function(){
        $('.pop_up_left').show();
    });
    $('.pop_up_left').click(function(){
        $('.pop_up_left').hide();
    });
    $('pop_up_closebutton').click(function(){
        $('.pop_up_left').hide();
    });

    $(".offer__pic__plus__right").click(function(){
        $('.pop_up_right').show();
    });
    $('.pop_up_right').click(function(){
        $('.pop_up_right').hide();
    });
    $('pop_up_closebutton').click(function(){
        $('.pop_up_right').hide();
    });

});

